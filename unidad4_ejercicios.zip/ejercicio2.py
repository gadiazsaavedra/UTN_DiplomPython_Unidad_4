"""Este código define una función lambda llamada
multiplicar_por_tres que toma un valor como entrada
y devuelve el resultado de multiplicar ese valor por 3.
Luego, se llama a la función lambda con un valor de entrada de (por ej.6)
y se imprime el resultado en la consola.
"""
multiplicar_por_tres = lambda valor: 3 * valor
print(multiplicar_por_tres(6))
